select * from author;
select * from book;
select * from bookauthor;
select * from bookcondition;
select * from bookreview;
select * from category;
select * from inventory;
select * from permrole;
select * from publisher;
select * from purchaselog;
select * from reviewer;
select * from state;
 select * from user; 

